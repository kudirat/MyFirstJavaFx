README

Course: cs400
Semester: Spring 2019
Project name: MyFirstJavaFx
Author: Kudirat Alimi Email: kalimi@wisc.edu

Notes or comments to the grader:

Done button and ComboBox have not been programmed to execute any events. However, they do appear. 